const botonInicio = document.getElementsByClassName('botonInicio');

botonInicio.addEventListener('click', () => {
    window.alert('Ay me cliqueaste :(');
})
